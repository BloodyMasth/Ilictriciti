
public class main {

	public static Echequier getTab(int [][] tab) {
		Echequier game = new Echequier();
		for (int i = 0; i<8; i++) {
			for (int j = 0; j<8; j++) {
				if (tab[i][j] != 0) {
					game.set(i, j, tab[i][j]);
				}
			}
		}
		return game;
	}
	
	public static int[] getStartIJ(int [][] tab) {
		int [] r = new int[2];
		
		for (int i = 0; i<8; i++) {
			for (int j = 0; j<8; j++) {
				if (tab[i][j] == -2) {
					r[0] = i;
					r[1] = j;
				}
			}
		}		
		
		return r;
	} 
	
	public static void backEnd(int [][] tab) {
		Pile <Euler> Pile = new Pile<Euler>();
		int i = getStartIJ(tab)[0],j = getStartIJ(tab)[1], found = 0;
		
		Euler coupPrecedent;
		int  choixPrecedent, nouveauChoix, numeroCoup;

		Echequier jeu=getTab(tab);
		jeu.affiche();
		choixPrecedent=0;
		numeroCoup=1;
		
		while (true){   
			
			nouveauChoix = jeu.choixSuivantPossible(i, j, choixPrecedent); 
			
			if (nouveauChoix!=-1){ 						
				Pile.Empile(new Euler(i,j,nouveauChoix)); 
				switch (nouveauChoix) {
				case 1:
					jeu.set(i+1, j,10);
					jeu.set(i+2, j,10);
					i=i+3;
					break;
				case 2:
					jeu.set(i+1, j,10);
					i=i+2;
					break;
				case 3:
					jeu.set(i+1, j,10);
					jeu.set(i+2, j,14);
					i=i+2;
					j=j+1;
					break;
				case 4:
					jeu.set(i+1, j,10);
					jeu.set(i+2, j,15);
					i=i+2;
					j=j-1;
					break;
				case 5:
					jeu.set(i, j+1,11);
					jeu.set(i, j+2,11);
					j=j+3;
					break;
				case 6:
					jeu.set(i, j+1,11);
					j=j+2;
					break;
				case 7:
					jeu.set(i, j+1,11);
					jeu.set(i, j+2,12);
					i=i+1;
					j=j+2;
					break;
				case 8:
					jeu.set(i, j+1,11);
					jeu.set(i, j+2,13);
					i=i-1;
					j=j+2;
					break;
				case 9:
					jeu.set(i-1, j,10);
					jeu.set(i-2, j,10);
					i=i-3;
					break;
				case 10:
					jeu.set(i-1, j,10);
					i=i-2;
					break;
				case 11:
					jeu.set(i-1, j,10);
					jeu.set(i-2, j,16);
					i=i-2;
					j=j-1;
					break;
				case 12:
					jeu.set(i-1, j,10);
					jeu.set(i-2, j,17);
					i=i-2;
					j=j+1;
					break;
				case 13:
					jeu.set(i, j-1,11);
					jeu.set(i, j-2,11);
					j=j-3;
					break;
				case 14:
					jeu.set(i, j-1,11);
					j=j-2;
					break;
				case 15:
					jeu.set(i, j-1,11);
					jeu.set(i, j-2,14);
					i=i-1;
					j=j-2;
					break;
				case 16:
					jeu.set(i, j-1,11);
					jeu.set(i+1, j-2,17);
					i=i+1;
					j=j-2;
					break;
			}
				numeroCoup=numeroCoup+1;
				if (jeu.get(i, j) == -3) {
					found = 1;
					break;
				}
				jeu.set(i, j,1);					
				choixPrecedent=0;		
				jeu.affiche();
			}
			else { 	
				//System.out.println("DEPILE");
				coupPrecedent = Pile.SommetPile();			
				Pile.Depile();								
				jeu.reset(i,j);                        
				i=coupPrecedent.posPrecedentX;
				j=coupPrecedent.posPrecedentY;			
				choixPrecedent=coupPrecedent.choixPrecedent; 
				numeroCoup=numeroCoup-1;						
			}
		}
		
		if (found == 1) {
			System.out.println("Calcul terminer");
			System.out.println("Nombre de coups effectue : " + numeroCoup);
			Interface.showMessage(1, numeroCoup);
			Interface.recup_case(jeu);
		}
		
	}
	
	public static void resetPipe(Echequier jeu) {
		for (int i=0;i<8;i++){
			for (int j=0; j<8;j++){
				
				if (jeu.get(i,j) == 10 || jeu.get(i,j) == 11 || jeu.get(i,j) == 12 || jeu.get(i,j) == 13 || jeu.get(i,j) == 14 || jeu.get(i,j) == 15 || jeu.get(i,j) == 16 || jeu.get(i,j) == 17) {
					jeu.reset(i,j);
				}
			}
		}
		Interface.recup_case(jeu);
	}
	
	public static void main(String[] args) {
		Interface gui = new Interface();
		gui.run();
	}

}
