public class Euler {
	
///////  ATTRIBUTS	
	
	int posPrecedentX;
	int posPrecedentY;
	int choixPrecedent;

	
/////// CONSTRUCTEURS	
	
	Euler(int i, int j, int choix){
		this.posPrecedentX=i;
		this.posPrecedentY=j;
		this.choixPrecedent=choix;
		
	}
}
