
public class createTuple {

		
		private int x;
		private int y;
		


		createTuple(int x, int y){
			this.setCoordX(x);
			this.setCoordY(y);
		}


		public int getCoordX() {
			return x;
		}


		public void setCoordX(int x) {
			this.x = x;
		}


		public int getCoordY() {
			return y;
		}


		public void setCoordY(int y) {
			this.y = y;
		}
		
		public String getCoordXY() {
			String mavar = "("+x+y+")";
			return mavar;
		}

}


